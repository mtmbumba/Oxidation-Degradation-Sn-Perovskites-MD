from pathlib import Path
import numpy as np,csv
R=Path(__file__).resolve().parents[1]; out=[]
for d in sorted((R/'02_inputs').glob('O*_R*')):
 for sp,fn in [('I','msd_I.dat'),('O','msd_O.dat')]:
  p=d/fn
  if not p.exists(): continue
  a=np.loadtxt(p,comments='#'); a=np.atleast_2d(a); t=a[:,0]*.001; y=a[:,-1]; m=(t>=2000)&(t<=8000)
  if m.sum()<5: continue
  slope=np.polyfit(t[m],y[m],1)[0]; D=slope/6*1e-4
  out.append([d.name,sp,D,slope])
with open(R/'03_analysis'/'diffusion_summary.csv','w',newline='') as f:
 w=csv.writer(f); w.writerow(['case','species','D_cm2_s','slope_A2_ps']); w.writerows(out)
print('trajectory-derived rows:',len(out))
