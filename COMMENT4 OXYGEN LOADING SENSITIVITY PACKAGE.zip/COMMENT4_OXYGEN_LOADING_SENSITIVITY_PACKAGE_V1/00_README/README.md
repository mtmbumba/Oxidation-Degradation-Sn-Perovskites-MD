# Comment 4 oxygen-loading sensitivity study
Fixed host: 3x3x3 MAPb0.5Sn0.5I3 = 27 formula units = 324 host atoms.
Loadings: 0, 1, 2, 3 O2; three independently placed/seeded replicas each (12 runs).
Baseline: 2 O2. Protocol: minimization; 1 ns NPT at 300 K; 10 ns NVT production; 1 fs timestep.
This package contains INPUTS, not fabricated simulation results. Execute with a validated LAMMPS installation.
The concentration series brackets the baseline so the reviewer-requested loading sensitivity can be quantified.
