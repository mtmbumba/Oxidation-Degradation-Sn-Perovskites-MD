#!/usr/bin/env python3
from pathlib import Path
import sys,csv,math
import numpy as np
import matplotlib.pyplot as plt

dump=Path(sys.argv[1])
outdir=Path(sys.argv[2]) if len(sys.argv)>2 else Path("O2_integrity_results")
outdir.mkdir(parents=True,exist_ok=True)

def mi(dx,L):
    return dx-L*round(dx/L)

records=[]; counts=[]
with dump.open(errors="ignore") as f:
    while True:
        line=f.readline()
        if not line: break
        if not line.startswith("ITEM: TIMESTEP"): continue
        step=int(f.readline().strip())
        assert f.readline().startswith("ITEM: NUMBER OF ATOMS")
        nat=int(f.readline().strip())
        f.readline()
        bounds=[]
        for _ in range(3):
            lo,hi,*_=map(float,f.readline().split())
            bounds.append((lo,hi))
        hdr=f.readline().strip().split()[2:]
        idx={k:i for i,k in enumerate(hdr)}
        O=[]
        for _ in range(nat):
            p=f.readline().split()
            if int(p[idx["type"]])==8:
                O.append({"id":int(p[idx["id"]]),"mol":int(p[idx["mol"]]),
                          "x":float(p[idx["x"]]),"y":float(p[idx["y"]]),"z":float(p[idx["z"]])})
        mols={}
        for a in O:
            mols.setdefault(a["mol"],[]).append(a)
        counts.append([step,len(O),len(mols),";".join(map(str,sorted(mols)))])
        for mol,aa in sorted(mols.items()):
            if len(aa)!=2:
                records.append([step,mol,"","","INVALID"])
                continue
            a,b=aa
            ds=[]
            for c,(lo,hi) in zip(["x","y","z"],bounds):
                ds.append(mi(b[c]-a[c],hi-lo))
            r=math.sqrt(sum(x*x for x in ds))
            records.append([step,mol,a["id"],b["id"],r])

with (outdir/"O2_counts_identity.csv").open("w",newline="") as f:
    w=csv.writer(f); w.writerow(["step","O_atoms","O2_molecules","molecule_ids"]); w.writerows(counts)
with (outdir/"OO_bond_lengths.csv").open("w",newline="") as f:
    w=csv.writer(f); w.writerow(["step","molecule_id","atom1","atom2","OO_A"]); w.writerows(records)

valid=[r for r in records if isinstance(r[-1],float)]
arr=np.array([[float(r[0]),float(r[1]),float(r[-1])] for r in valid])

summary=[]
for mol in sorted(set(arr[:,1].astype(int))):
    x=arr[arr[:,1]==mol,2]
    summary.append([mol,x.mean(),x.std(ddof=1),x.min(),x.max(),len(x)])
with (outdir/"OO_summary.csv").open("w",newline="") as f:
    w=csv.writer(f); w.writerow(["molecule_id","mean_A","sd_A","min_A","max_A","n_frames"]); w.writerows(summary)

fig,ax=plt.subplots(figsize=(7,4.5))
for mol in sorted(set(arr[:,1].astype(int))):
    x=arr[arr[:,1]==mol]
    ax.plot(x[:,0]*0.001,x[:,2],label=f"O2 molecule {mol}")
ax.set_xlabel("Time (ps)")
ax.set_ylabel("O–O distance (Å)")
ax.legend()
fig.tight_layout()
fig.savefig(outdir/"OO_vs_time.png",dpi=250)
plt.close(fig)

fig,ax=plt.subplots(figsize=(6,4.5))
for mol in sorted(set(arr[:,1].astype(int))):
    x=arr[arr[:,1]==mol,2]
    ax.hist(x,bins=50,density=True,histtype="step",label=f"O2 molecule {mol}")
ax.set_xlabel("O–O distance (Å)")
ax.set_ylabel("Probability density")
ax.legend()
fig.tight_layout()
fig.savefig(outdir/"OO_distribution.png",dpi=250)
plt.close(fig)

print("Completed:",outdir)
