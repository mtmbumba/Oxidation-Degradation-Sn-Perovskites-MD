#!/bin/bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
FF="$ROOT/03_forcefield/forcefield_executable_candidate.in"
MODEL="$ROOT/02_topology_models/MAPbSnI3_333_O2_neutral.data"

LAMMPS_BIN="${LAMMPS_BIN:-}"
if [[ -z "$LAMMPS_BIN" ]]; then
  for x in lmp lmp_mpi lammps; do
    if command -v "$x" >/dev/null 2>&1; then
      LAMMPS_BIN="$(command -v "$x")"
      break
    fi
  done
fi

if [[ -z "$LAMMPS_BIN" ]]; then
  echo "ERROR: No LAMMPS executable found. Set LAMMPS_BIN=/path/to/lmp"
  exit 2
fi

TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
cp "$MODEL" "$TMP/system.data"
cp "$FF" "$TMP/forcefield.in"

cat > "$TMP/smoke.in" <<'EOF'
units metal
atom_style full
boundary p p p
read_data system.data
include forcefield.in

thermo 1
thermo_style custom step temp pe ke etotal press vol

# Static energy evaluation
run 0

# Very short minimization smoke test
min_style fire
minimize 1.0e-6 1.0e-8 100 1000

write_data smoke_minimized.data
EOF

cd "$TMP"
"$LAMMPS_BIN" -in smoke.in | tee smoke_test.log

echo "Smoke test completed."
echo "Inspect smoke_test.log for ERROR, Lost atoms, NaN, or extreme energies/pressures."
