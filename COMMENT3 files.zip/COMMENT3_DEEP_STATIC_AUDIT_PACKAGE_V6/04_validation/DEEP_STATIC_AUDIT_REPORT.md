# Deep static audit report — Comment 3 V6

## Result
PASS WITH DOCUMENTED CAVEATS

## Checks completed
- All three supercell data files were parsed.
- Header atom/bond/angle/dihedral counts agree with the actual sections.
- Bond type mapping is internally consistent:
  - type 1 = C(MA)-N(MA)
  - type 2 = C(MA)-H(C)
  - type 3 = N(MA)-H(N)
  - type 4 = O-O
- All 36 unique atom-type pair interactions are explicitly defined.
- Bond coefficients 1-4, angle coefficients 1-4, and dihedral coefficient 1 are present.
- The 3x3x3 oxygen-loaded file contains 328 atoms = 324-host atoms + 2 O2 molecules.
- The small non-zero total charges are explained by rounding of the published parent charges:
  each MAPb/SnI3 formula unit carries approximately -0.0004 e with the tabulated values.
  This gives -0.0108 e, -0.0256 e, and -0.0500 e for 27, 64, and 125 formula units,
  respectively; the files reproduce those values.

## Model counts
- MAPbSnI3_333_O2_neutral.data: atoms=328, bonds=191, angles=324, dihedrals=243, formula units=27, O2=2, total charge=-0.010800 e
- MAPbSnI3_444_O2_neutral.data: atoms=778, bonds=453, angles=768, dihedrals=576, formula units=64, O2=5, total charge=-0.025600 e
- MAPbSnI3_555_O2_neutral.data: atoms=1518, bonds=884, angles=1500, dihedrals=1125, formula units=125, O2=9, total charge=-0.050000 e

## Remaining publication caveats
1. This is a static consistency audit, not a LAMMPS execution test.
2. Pb-Sn and Sn-MA cross terms remain documented transfer/combining assumptions.
3. Physical validation still requires a real LAMMPS run and structural/dynamical checks.
4. The manuscript should distinguish the 324-atom pristine 3x3x3 host from the
   328-atom oxygen-loaded simulation system.

## Recommended closure criterion
Comment 3 can be described as fully addressed only after:
- the supplied smoke test runs successfully in LAMMPS;
- the resulting log is deposited;
- no undefined coefficients, NaN, lost atoms, or immediate collapse occur;
- the deposited archive is the same checksum/version cited in the manuscript.
