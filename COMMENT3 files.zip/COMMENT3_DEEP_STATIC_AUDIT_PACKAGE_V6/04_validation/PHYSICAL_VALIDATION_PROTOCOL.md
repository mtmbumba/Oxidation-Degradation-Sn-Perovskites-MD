# Physical validation protocol required before publication

The V5 package has passed the static 36-pair/topology audit. It has NOT yet passed
a real LAMMPS execution test in this environment because LAMMPS is not installed.

After running `run_lammps_smoke_test.sh`, proceed in this order:

1. Parser / energy sanity
   - no undefined pair/bond/angle/dihedral coefficients
   - no NaN energies, lost atoms, or immediate lattice collapse

2. Energy-minimized structure
   - preserve corner-sharing Pb/Sn-I framework
   - no unphysical O2 dissociation
   - check nearest-neighbour Pb-I and Sn-I distances

3. Short NVT stability test
   - 300 K, 50-100 ps
   - bounded temperature and total energy
   - O-O bond remains near molecular reference value

4. NPT structural validation
   - lattice parameter/density stable
   - Pb-I RDF near literature benchmark
   - Sn-I RDF close to independent Sn-I benchmark
   - coordination numbers remain physically meaningful

5. Production validation
   - 3 independent replicas
   - MSD linearity documented over selected fit interval
   - RDF/CN uncertainties reported

6. Finite-size validation
   - 3x3x3 -> 4x4x4 -> 5x5x5
   - structural and transport changes decrease with system size

The five Sn cross terms added in V4/V5 are transfer/combine assumptions.
A successful parser run alone does not validate them physically.
