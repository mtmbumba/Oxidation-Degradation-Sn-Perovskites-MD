#!/usr/bin/env python3
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]
ff=(ROOT/"03_forcefield"/"forcefield_executable_candidate.in").read_text()
issues=[]
pairs=set()
for line in ff.splitlines():
    s=line.strip()
    if s.startswith("pair_coeff"):
        p=s.split()
        pairs.add(tuple(sorted((int(p[1]),int(p[2])))))
expected={(i,j) for i in range(1,9) for j in range(i,9)}
missing=sorted(expected-pairs)
if missing:
    issues.append("Missing pair_coeff pairs: "+str(missing))
for model in (ROOT/"02_topology_models").glob("*.data"):
    txt=model.read_text()
    for token in ["Angles","Dihedrals","8 atom types","4 angle types","1 dihedral types"]:
        if token not in txt:
            issues.append(f"{model.name}: missing {token}")
print("STATIC MATRIX AUDIT")
if issues:
    print("FAIL")
    for x in issues:
        print(" -",x)
    sys.exit(1)
print("PASS: all 36 atom-type pairs have explicit definitions and MA topology sections are present.")
print("NOTE: static completeness is not physical validation.")
