# V4 status: statically complete executable candidate

All 36 atom-type pairs now have explicit interaction definitions in
`forcefield_executable_candidate.in`.

## New candidate assumptions used to close the five remaining Sn pairs
- Pb-Sn: Buckingham combining rule:
  A = sqrt(A_PbPb*A_SnSn) = 234563.424259 eV
  rho = (rho_PbPb+rho_SnSn)/2 = 0.329400 A
  C = sqrt(C_PbPb*C_SnSn) = 0.000000 eV A^6
- Sn-C(MA), Sn-N(MA), Sn-H(C), Sn-H(N):
  direct transfer of the corresponding published Pb-MA functional forms
  and coefficients as an isovalent B-site starting approximation.

These five terms are MODEL ASSUMPTIONS, not published Seijas-Bellido Sn parameters.

## Interpretation
This package is now statically complete enough for an actual LAMMPS parser/smoke-test
attempt. It is not yet a physically validated production force field. Validation must
check energy stability, lattice dimensions, Pb-I/Sn-I RDFs, coordination numbers,
O2 integrity, and sensitivity to the transferred Sn-MA/Pb-Sn terms.
