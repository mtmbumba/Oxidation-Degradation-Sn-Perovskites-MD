# Data and Code Availability — final wording after repository deposition

The complete computational reproducibility package supporting this study is available
at [PERMANENT DOI/REPOSITORY]. The archive contains the full MAPb0.5Sn0.5I3/O2
production and finite-size supercell models; atom-type assignments, masses, partial
charges and molecular topology; the complete parent Pb/I/MA force-field implementation;
the explicitly documented Sn/O extension; and the LAMMPS scripts required for
initialization, minimization, equilibration and production dynamics. Parameter-provenance
tables, a complete pair-interaction matrix, validation scripts, representative run logs
and the analysis workflow used for structural and transport descriptors are also included.
A versioned README maps each deposited file to the corresponding calculation reported
in the manuscript and Supporting Information.
