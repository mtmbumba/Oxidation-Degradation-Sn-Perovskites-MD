# Comment 3 parameter/topology package V3

This package incorporates the uploaded primary Supporting Information of
Seijas-Bellido et al. and replaces earlier approximate parent Pb/I/MA parameters
with exact values from Tables S1-S5.

## What is now exact
- Pb/I/MA masses and charges.
- Parent Pb/I/MA pair parameters.
- MA bond, angle, and dihedral parameters.
- Parent-model C=0 treatment for Buckingham dispersion term.
- MA topology has been restored in the 3x3x3, 4x4x4, and 5x5x5 reconstructed models.

Generated topology counts:
{
  "MAPbSnI3_333_O2_neutral.data": [
    324,
    243
  ],
  "MAPbSnI3_444_O2_neutral.data": [
    768,
    576
  ],
  "MAPbSnI3_555_O2_neutral.data": [
    1500,
    1125
  ]
}

## O2 implementation
The Wang-Hou-Heinz 12-6 model uses E_bond = (Kr/2)(r-r0)^2.
LAMMPS `bond_style harmonic` uses E = K(r-r0)^2; therefore the LAMMPS
coefficient is Kr/2 after energy-unit conversion. The source LJ expression uses
its quoted sigma as the minimum-distance parameter; for LAMMPS `lj/cut`, the
equivalent sigma is r_min/2^(1/6). These conversions are documented in
`O2_LAMMPS_conversion.csv`.

## Remaining blockers
The uploaded parent SI has no Sn parameters. The previously reconstructed study
files provide Sn-I, Sn-Sn and O-Sn/O-Pb/O-I extension values, but do not
establish Pb-Sn or Sn-MA pair terms. Consequently this package deliberately
does NOT label `forcefield_parent_exact_extension_partial.in` as a final
production force field.

Required unresolved pairs:
- Pb-Sn
- Sn-C(MA)
- Sn-N(MA)
- Sn-H(C)
- Sn-H(N)

These need explicit provenance/parameterization before the force field can be
called complete and independently executable.
