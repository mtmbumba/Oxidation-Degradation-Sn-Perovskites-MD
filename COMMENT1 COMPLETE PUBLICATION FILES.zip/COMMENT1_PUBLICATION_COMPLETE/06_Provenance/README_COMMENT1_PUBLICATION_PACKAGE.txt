COMMENT 1 — COMPLETE PUBLICATION PACKAGE

Manuscript: Oxygen Diffusion and Structural Degradation in Mixed Pb–Sn Halide Perovskites: A Molecular Dynamics Study

Recovered Comment 1 basis:
The reviewer found the theoretical procedure difficult to understand. The revision reorganized the computational workflow, clarified classical MD as the sole simulation framework, expanded reproducibility information, and reorganized the Results from oxygen diffusion through structural evolution, transport, mechanism, and literature benchmarking.

CONTENTS
01_Manuscript — latest recovered August 2026 manuscript containing the 3×3×3 / 4×4×4 / 5×5×5 finite-size discussion.
02_Response_to_Reviewer — response documents used during the revision.
03_Supporting_Information — recovered Supporting Information used in the revision.
04_Finite_Size_MD — adopted benchmark dataset, references, provenance, reconstructed neutral-supercell model files, and publication-formatted benchmark table.
05_Figures_and_Source_Data — redesigned figures and numerical source workbooks associated with the MD revision.
06_Provenance — manifest and this guide.

CRITICAL PUBLICATION PROVENANCE
The reconstructed model files and the literature-informed adopted finite-size dataset do not demonstrate that 3×3×3, 4×4×4, and 5×5×5 production trajectories were executed in this environment. The adopted values may be used only when explicitly identified as literature-informed/adopted sensitivity values. They must not be represented as newly computed MD outputs.

CORE REFERENCES
[1] J. Phys. Chem. Lett. (2022), DOI 10.1021/acs.jpclett.2c00273.
[2] RSC Advances 10 (2020), DOI 10.1039/D0RA02584D.
[3] Seijas-Bellido et al., J. Chem. Inf. Model. 62 (2022) 6423–6435, DOI 10.1021/acs.jcim.1c01506.
[4] Aristidou et al., Nature Communications 8, 15218 (2017), DOI 10.1038/ncomms15218.
