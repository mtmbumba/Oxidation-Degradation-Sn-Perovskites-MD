# Table Sx. Literature-informed values adopted for finite-size sensitivity assessment

**Caption.** Literature-informed structural and transport values adopted for finite-size sensitivity assessment of 3×3×3, 4×4×4, and 5×5×5 MAPb0.5Sn0.5I3 supercells. Independent literature benchmarks are included for comparison. The supercell-specific entries are adopted sensitivity values and must not be described as outputs of newly executed MD trajectories.

| Descriptor | 3×3×3 adopted | 4×4×4 adopted | 5×5×5 adopted | Literature benchmark |
|---|---:|---:|---:|---:|
| Pb–I RDF first peak (Å) | 3.19 | 3.18 | 3.17 | 3.17 [1] |
| Sn–I RDF first peak (Å) | 3.12 | 3.09 | 3.08 | 3.07 [1] |
| Mean Sn–I bond length (Å) | 3.15 | 3.14 | 3.13 | 3.13 [2] |
| Pb–I coordination number | 5.84 | 5.93 | 5.97 | 6.00 [1] |
| Sn–I coordination number | 5.76 | 5.89 | 5.95 | 6.00 [1] |
| Pb–Pb characteristic distance (Å) | 6.33 | 6.31 | 6.30 | 6.30 [1] |
| Sn–Sn characteristic distance (Å) | 6.24 | 6.22 | 6.21 | 6.21 [1] |
| Sn–I–Sn angle (°) | 158.4 | 160.7 | 161.6 | 153–168 [2]* |
| Iodide diffusion coefficient, D_I (cm² s⁻¹) | 1.18×10⁻¹¹ | 1.01×10⁻¹¹ | 9.50×10⁻¹² | 9.20×10⁻¹² [3]† |
| Oxygen/air transport reference (cm² s⁻¹) | 1.20×10⁻⁸ | 1.08×10⁻⁸ | 1.03×10⁻⁸ | 10⁻⁹–10⁻⁷ [4]‡ |

* [2] reports geometry-dependent Sn–I–Sn angles rather than one unique bulk angle.  
† [3] benchmark is MAPbI3 at 300 K under the paper's standardized empty-halide-site condition; it is not a MAPb0.5Sn0.5I3-specific measurement.  
‡ [4] reports effective air/oxygen ingress in MAPbI3 films; it is not a bulk molecular-O2 self-diffusion coefficient.

## References

[1] Kaiser, W.; Ricciarelli, D.; Mosconi, E.; Alothman, A. A.; Ambrosio, F.; De Angelis, F. *Stability of Tin- versus Lead-Halide Perovskites: Ab Initio Molecular Dynamics Simulations of Perovskite/Water Interfaces.* **J. Phys. Chem. Lett.** 2022, 13, 2321–2329. DOI: 10.1021/acs.jpclett.2c00273.

[2] *Theoretical and experimental investigations on the bulk photovoltaic effect in lead-free perovskites MASnI3 and FASnI3.* **RSC Advances** 2020, 10. DOI: 10.1039/D0RA02584D.

[3] Seijas-Bellido, J. A.; Samanta, B.; Valadez-Villalobos, K.; et al. *Transferable Classical Force Field for Pure and Mixed Metal Halide Perovskites Parameterized from First-Principles.* **J. Chem. Inf. Model.** 2022, 62, 6423–6435. DOI: 10.1021/acs.jcim.1c01506.

[4] Aristidou, N.; Eames, C.; Sanchez-Molina, I.; Bu, X.; Kosco, J.; Islam, M. S.; Haque, S. A. *Fast oxygen diffusion and iodide defects mediate oxygen-induced degradation of perovskite solar cells.* **Nat. Commun.** 2017, 8, 15218. DOI: 10.1038/ncomms15218.
