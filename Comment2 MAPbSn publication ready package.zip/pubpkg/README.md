# MAPb0.5Sn0.5I3 literature-assisted finite-size package

This package accompanies a literature-informed finite-size sensitivity assessment for 3×3×3, 4×4×4 and 5×5×5 MAPb0.5Sn0.5I3 models.

## Contents
- `TABLE_SX_PUBLICATION_READY.md`: manuscript/SI-ready table, caption, notes and references.
- `ADOPTED_LITERATURE_INFORMED_DATA.csv`: machine-readable adopted values and provenance labels.
- `PROVENANCE_AND_PUBLICATION_LIMITS.md`: mandatory interpretation and reporting limits.
- `REFERENCES.bib`: BibTeX entries for the supporting literature.
- `v2_model/`: previously reconstructed neutral structural scaffold and provisional LAMMPS inputs.

## Critical status statement
The supercell-specific adopted values are literature-informed sensitivity values. They are not outputs of executed 3×3×3, 4×4×4 or 5×5×5 trajectories. The included v2 LAMMPS model is a reconstruction scaffold and should not be represented as the numerical source of the adopted table.
