# Charge-model reconciliation report

The originally supplied SI charges generate a strongly non-neutral explicit system.

Parent Seijas-Bellido et al. transferable MAPbI3 force field charges:
C_MA = -0.4422
N_MA = -0.9531
H_C  = +0.28 (three methyl H)
H_N  = +0.74 (three ammonium H)
Pb   = +1.9713
I    = -1.212

MA charge = -0.4422 -0.9531 + 3(0.28) + 3(0.74) = +1.6647 e
MAPbI3 formula charge = 1.6647 + 1.9713 - 3(1.212) = 0.0000 e

For the reconstruction only, Sn is treated as an isovalent B-site substitution with q_Sn=q_Pb
to preserve charge neutrality. This is a reconstruction assumption and must not be described as
a literature-derived Sn parameter without a dedicated Sn parameterization source.

Neutral molecular O2 is represented with q_O=0 in this v2 charge scaffold. This differs from
the uploaded SI value q_O=-0.21 and therefore must be validated/re-parameterized before being
reported as the final oxygen model.

This v2 package is intended to fix the electrostatic bookkeeping so that a physically neutral
host model can be constructed. It does not by itself validate the Sn/O short-range potentials.
