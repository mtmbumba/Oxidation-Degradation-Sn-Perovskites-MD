
import math, random, argparse
A=6.30

# Distinguish methyl and ammonium hydrogens because the parent AMBER-compatible
# force field assigns different charges.
TYPE={"Pb":1,"Sn":2,"I":3,"C":4,"N":5,"HC":6,"HN":7,"O":8}
MASS={"Pb":207.20,"Sn":118.71,"I":126.90447,"C":12.011,"N":14.007,"HC":1.008,"HN":1.008,"O":15.999}
Q={"Pb":1.9713,"Sn":1.9713,"I":-1.212,"C":-0.4422,"N":-0.9531,"HC":0.28,"HN":0.74,"O":0.0}
rCN,rCH,rNH=1.47,1.09,1.01

def tetra(r,left=True):
    x=(-r/3 if left else r/3); yz=(r*r-x*x)**0.5
    return [(x,yz,0),(x,-0.5*yz,0.8660254038*yz),(x,-0.5*yz,-0.8660254038*yz)]

def rot(v,rng):
    u1,u2,u3=rng.random(),rng.random(),rng.random()
    x=math.sqrt(1-u1)*math.sin(2*math.pi*u2); y=math.sqrt(1-u1)*math.cos(2*math.pi*u2)
    z=math.sqrt(u1)*math.sin(2*math.pi*u3); w=math.sqrt(u1)*math.cos(2*math.pi*u3)
    R=((1-2*(y*y+z*z),2*(x*y-z*w),2*(x*z+y*w)),
       (2*(x*y+z*w),1-2*(x*x+z*z),2*(y*z-x*w)),
       (2*(x*z-y*w),2*(y*z+x*w),1-2*(x*x+y*y)))
    return tuple(sum(R[i][j]*v[j] for j in range(3)) for i in range(3))
def wrap(p,L): return tuple(x%L for x in p)
def mid(a,b,L):
    return sum((a[i]-b[i]-round((a[i]-b[i])/L)*L)**2 for i in range(3))**0.5

def build(n,seed):
    rng=random.Random(seed); L=n*A
    sites=[(i,j,k) for i in range(n) for j in range(n) for k in range(n)]
    nsn=len(sites)//2; sn=set(rng.sample(range(len(sites)),nsn))
    atoms=[]; bonds=[]; aid=1; mol=1
    for idx,(i,j,k) in enumerate(sites):
        base=(i*A,j*A,k*A); B="Sn" if idx in sn else "Pb"
        atoms.append([aid,0,TYPE[B],Q[B],*base,B]); aid+=1
        for off in ((A/2,0,0),(0,A/2,0),(0,0,A/2)):
            p=wrap(tuple(base[d]+off[d] for d in range(3)),L)
            atoms.append([aid,0,TYPE["I"],Q["I"],*p,"I"]); aid+=1
        c=((i+0.5)*A,(j+0.5)*A,(k+0.5)*A)
        C=(-rCN/2,0,0); N=(rCN/2,0,0)
        local=[("C",C),("N",N)]
        local += [("HC",tuple(C[d]+v[d] for d in range(3))) for v in tetra(rCH,True)]
        local += [("HN",tuple(N[d]+v[d] for d in range(3))) for v in tetra(rNH,False)]
        ids=[]
        for sym,p in local:
            rp=rot(p,rng); xyz=wrap(tuple(c[d]+rp[d] for d in range(3)),L)
            atoms.append([aid,mol,TYPE[sym],Q[sym],*xyz,sym]); ids.append(aid); aid+=1
        bonds.append([len(bonds)+1,1,ids[0],ids[1]])
        for h in ids[2:5]: bonds.append([len(bonds)+1,2,ids[0],h])
        for h in ids[5:8]: bonds.append([len(bonds)+1,3,ids[1],h])
        mol+=1
    pristine=len(atoms)
    no2={3:2,4:5,5:9}[n]
    existing=[tuple(a[4:7]) for a in atoms]
    for _ in range(no2):
        for trial in range(20000):
            c=(rng.random()*L,rng.random()*L,rng.random()*L); u=rot((1,0,0),rng); h=0.605
            o1=wrap(tuple(c[d]-h*u[d] for d in range(3)),L); o2=wrap(tuple(c[d]+h*u[d] for d in range(3)),L)
            if min(mid(o1,p,L) for p in existing)>1.6 and min(mid(o2,p,L) for p in existing)>1.6:
                atoms.append([aid,mol,8,Q["O"],*o1,"O"]); a1=aid; aid+=1
                atoms.append([aid,mol,8,Q["O"],*o2,"O"]); a2=aid; aid+=1
                bonds.append([len(bonds)+1,4,a1,a2]); existing += [o1,o2]; mol+=1; break
        else: raise RuntimeError("O2 placement failed")
    return atoms,bonds,L,pristine

def write(path,atoms,bonds,L):
    with open(path,"w") as f:
        f.write("Neutral-host reconstructed MAPb0.5Sn0.5I3 + O2 model\n\n")
        f.write(f"{len(atoms)} atoms\n{len(bonds)} bonds\n0 angles\n0 dihedrals\n\n")
        f.write("8 atom types\n4 bond types\n0 angle types\n0 dihedral types\n\n")
        f.write(f"0.0 {L:.8f} xlo xhi\n0.0 {L:.8f} ylo yhi\n0.0 {L:.8f} zlo zhi\n\nMasses\n\n")
        for s in ("Pb","Sn","I","C","N","HC","HN","O"):
            f.write(f"{TYPE[s]} {MASS[s]} # {s}\n")
        f.write("\nAtoms # full\n\n")
        for a in atoms:
            i,m,t,q,x,y,z,s=a
            f.write(f"{i} {m} {t} {q:.6f} {x:.8f} {y:.8f} {z:.8f} # {s}\n")
        f.write("\nBonds\n\n")
        for b in bonds: f.write("%d %d %d %d\n"%tuple(b))

ap=argparse.ArgumentParser(); ap.add_argument("--n",type=int,required=True); ap.add_argument("--seed",type=int,default=2026); ap.add_argument("--out",required=True)
a=ap.parse_args(); atoms,bonds,L,p=build(a.n,a.seed); write(a.out,atoms,bonds,L)
print(f"{a.n}x{a.n}x{a.n}: pristine={p}, with_O2={len(atoms)}, total_charge={sum(x[3] for x in atoms):.8f} e")
